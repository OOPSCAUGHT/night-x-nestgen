to set up opal skid 

its for eclipes
./gradlew genSources
./gradlew eclipse
if anything gose worng dm me udichi_85138
